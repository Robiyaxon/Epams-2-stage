const Page = require("./page.js");
class CloudGoogle extends Page {
  get searchButton () {
    return $(
      "/html/body/section/devsite-header/div/div[1]/div/div/div[2]/devsite-search/form"
    );
  }

  get select10() {
    return $("//li[text()='10 Minutes']");
  }

  get newPost() {
    return $("#postform-text");
  }
  get pastName() {
    return $("#postform-name");
  }
  async open() {
    super.open("https://cloud.google.com/");
  }
  async cloudGoogle(username, password) {
    await this.searchButton.waitForDisplayed();
    await this.searchButton.click();
  }
}
module.exports = CloudGoogle;
