const CloudGoogle = require("../po/cluodGoogle");
const PastebinPage = new PastebinPage();
describe("Pestbin service", () => {
  it("should open home page", async () => {
    await CloudGoogle.open();
    // await CloudGoogle.cloudGoogle("Hello from WebDriver", "helloweb");
    await browser.pause(5000);


    
  });
});
