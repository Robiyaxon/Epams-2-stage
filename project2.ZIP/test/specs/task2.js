import { Builder, By, Key, until } from "selenium-webdriver";
async function automateScript() {
  const driver = await new Builder().forBrowser("chrome").build();
  await driver.get("https://cloud.google.com/");
  const searchButton = await driver.wait(
    until.elementLocated(
      By.xpath(
        "/html/body/section/devsite-header/div/div[1]/div/div/div[2]/devsite-search/form")));
  await searchButton.click();
  await driver
    .findElement(By.name("q"))
    .sendKeys("Google Cloud Platform Pricing Calculator", Key.RETURN);
  const calculatorLink = await driver.wait(
    until.elementLocated( By.xpath("(//a[.='Google Cloud Pricing Calculator'])[1]")));
  calculatorLink.click();
  const quantityInput = await driver.wait(until.elementLocated(By.id(`input_98`)));
  await quantityInput.click();
  await quantityInput.clear();
  await quantityInput.sendKeys("4");
  
}
automateScript();
